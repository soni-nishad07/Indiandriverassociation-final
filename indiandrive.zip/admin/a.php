<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel Sidebar</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../css/admin.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <style>
        /* Base Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            /* background-color: #f4f4f4; */
        }

        .sidebar {
            width: 260px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background-color: white;
            color: black;
            padding-top: 20px;
            display: flex;
            flex-direction: column;
        }

        .sidebar img {
            width: 25px;
            margin-right: 10px;
        }

        .menu {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .menu div {
            display: flex;
            align-items: center;
            padding: 15px;
        }

        .menu li {
            margin-left: 10px;
            font-size: 16px;
            font-family: 'Arial', sans-serif;
        }

        .menu a {
            text-decoration: none;
            color: black;
            display: flex;
            align-items: center;
            font-weight: bold;
        }

        .menu a:hover {
            background: #D91A21;
            padding: 10px;
            border-radius: 5px;
        }

        .menu a.active {
            background-color: #ff4242;
            color: white;
            padding: 10px;
            border-radius: 5px;
        }

        /* Responsive Styles */
        @media (max-width: 1024px) {
            .sidebar {
                width: 220px;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
                margin-top:25%;
            }
        }

        @media (max-width: 576px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                flex-direction: row;
                flex-wrap: wrap;
            }

            .menu {
                display: flex;
                justify-content: space-around;
                flex-wrap: wrap;
                margin: 10px 0;
            }

            .menu div {
                padding: 10px;
            }

            .menu li {
                font-size: 14px;
            }
        }
    </style>
</head>

<body>
    <div class="sidebar">
        <ul class="menu">
            <div>
                <img src="../images/side.png" alt="">
                <a href="access_management.php">
                    <li>Staff Login</li>
                </a>
            </div>
            <div>
                <img src="../images/side.png" alt="">
                <a href="drivers_info.php">
                    <li>Drivers Information</li>
                </a>
            </div>
            <div>
                <img src="../images/side3.png" alt="">
                <a href="social_groups.php">
                    <li>WhatsApp & Telegram Group</li>
                </a>
            </div>
        </ul>
    </div>

   
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>

</html>