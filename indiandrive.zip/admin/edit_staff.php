<?php
include('conn.php');

if (isset($_GET['id'])) {
    $staff_id = $_GET['id'];
    
    // Fetch staff details
    $query = "SELECT * FROM staff_members WHERE staff_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $staff_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $staff = $result->fetch_assoc();
    
    if (!$staff) {
        echo "Staff member not found.";
        exit();
    }
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $staff_name = $_POST['staff_name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $status = $_POST['status'];

        $updateQuery = "UPDATE staff_members SET staff_name = ?, email = ?, phone = ?, status = ? WHERE staff_id = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param('sssss', $staff_name, $email, $phone, $status, $staff_id);

        if ($stmt->execute()) {
            header("Location: access_management.php?success=1");
            exit();
        } else {
            $errorMessage = "Error: " . $stmt->error;
        }
    }
} else {
    echo "No staff ID provided.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Staff Member</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<div class="form-container">
    <h2 style="margin-left:12%">Edit Staff Member</h2>

    <?php if (isset($errorMessage)) : ?>
        <p class="error-message"><?php echo $errorMessage; ?></p>
    <?php endif; ?>

    <form action="edit_staff.php?id=<?php echo htmlspecialchars($staff_id); ?>" method="POST">
        <label for="staff_name">Staff Name:</label>
        <input type="text" id="staff_name" name="staff_name" value="<?php echo htmlspecialchars($staff['staff_name']); ?>" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($staff['email']); ?>" required>

        <label for="phone">Phone:</label>
        <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($staff['phone']); ?>" required>
        <label for="phone">Password:</label>
        <input type="text" id="password" name="password" value="<?php echo htmlspecialchars($staff['password']); ?>" required>

        <label for="status">Status:</label>
        <select id="status" name="status" required>
            <option value="active" <?php echo $staff['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
            <option value="inactive" <?php echo $staff['status'] == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
        </select>
        <br>
        <button type="submit" style="background-color:green; margin-top:2%; padding:5px;">Update Staff Member</button>
    </form>
</div>

</body>
</html>
