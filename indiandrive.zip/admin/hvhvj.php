<?php
include('conn.php');

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Driver ID is required.");
}

$driver_id = $_GET['id'];

$query = "SELECT driver_name, phone, dl_number, area_postal_code, address, license_expiry, vehicle_type, driver_photo FROM driver_info WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $driver_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Driver not found.");
}

$driver = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $driver_name = $_POST['driver_name'];
    $phone = $_POST['phone'];
    $dl_number = $_POST['dl_number'];
    $area_postal_code = $_POST['area_postal_code'];
    $address = $_POST['address'];
  
    $license_expiry = $_POST['license_expiry'];
    $vehicle_type = $_POST['vehicle_type'];

    $driver_photo = $driver['driver_photo'];
    if (!empty($_FILES['driver_photo']['name'])) {
        $target_dir = "images/";
        $target_file = $target_dir . basename($_FILES['driver_photo']['name']);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        $check = getimagesize($_FILES['driver_photo']['tmp_name']);
        if ($check === false) {
            $errorMessage = "File is not an image.";
        } else {
            if (move_uploaded_file($_FILES['driver_photo']['tmp_name'], $target_file)) {
                $driver_photo = $target_file; 
            } else {
                $errorMessage = "Error uploading the image.";
            }
        }
    }

    $updateQuery = "UPDATE driver_info SET driver_name = ?, phone = ?, dl_number = ?, area_postal_code = ?, address = ?, license_expiry = ?, vehicle_type = ?, driver_photo = ? WHERE id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("ssssssssssi", $driver_name, $phone, $dl_number, $area_postal_code, $address, $license_expiry, $vehicle_type, $driver_photo, $driver_id);

    if ($stmt->execute()) {
        header("Location: drivers_info.php?success=Driver updated successfully");
        exit();
    } else {
        $errorMessage = "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Driver</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>

<body>
    <div class="form-container">
        <h2 style="margin-left:12%">Edit Driver</h2>

        <?php if (isset($errorMessage)) : ?>
            <p class="error-message"><?php echo $errorMessage; ?></p>
        <?php endif; ?>

        <form action="edit_driver.php?id=<?php echo htmlspecialchars($driver_id); ?>" method="POST" enctype="multipart/form-data">
            <label for="driver_name">Driver Name:</label>
            <input type="text" id="driver_name" name="driver_name" value="<?php echo htmlspecialchars($driver['driver_name']); ?>" required>

            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($driver['phone']); ?>" maxlength="10" required>

            <label for="dl_number">DL Number:</label>
            <input type="text" id="dl_number" name="dl_number" value="<?php echo htmlspecialchars($driver['dl_number']); ?>" required>

            <label for="area_postal_code">Area Postal Code:</label>
            <input type="text" id="area_postal_code" name="area_postal_code" value="<?php echo htmlspecialchars($driver['area_postal_code']); ?>" required>

            <label for="address">Address:</label>
            <textarea cols="50" rows="3" id="address" name="address" required><?php echo htmlspecialchars($driver['address']); ?></textarea>

 
            <label for="license_expiry">License Expiry:</label>
            <input type="date" id="license_expiry" name="license_expiry" value="<?php echo htmlspecialchars($driver['license_expiry']); ?>" required>

            <div class="form-group">
                <label for="vehicle_type">Vehicle Type:</label>
                <select id="vehicle_type" name="vehicle_type" required>
                    <option value="" disabled>Select your vehicle type</option>
                    <option value="car" <?php echo ($driver['vehicle_type'] == 'car') ? 'selected' : ''; ?>>Car</option>
                    <option value="truck" <?php echo ($driver['vehicle_type'] == 'truck') ? 'selected' : ''; ?>>Truck</option>
                    <option value="motorcycle" <?php echo ($driver['vehicle_type'] == 'motorcycle') ? 'selected' : ''; ?>>Motorcycle</option>
                    <option value="bus" <?php echo ($driver['vehicle_type'] == 'bus') ? 'selected' : ''; ?>>Bus</option>
                    <option value="auto" <?php echo ($driver['vehicle_type'] == 'auto') ? 'selected' : ''; ?>>Auto</option>

                </select>
            </div>

            <label for="driver_photo">Driver Photo:</label>
            <input type="file" id="driver_photo" name="driver_photo">

            <?php if (!empty($driver['driver_photo'])): ?>
                <img src="<?php echo htmlspecialchars($driver['driver_photo']); ?>" alt="Current Driver Photo" style="max-width: 100px; margin-top: 10px;">
            <?php endif; ?>

            <br>
            <button type="submit" style="background-color:green; margin-top:2%; padding:5px;">Update Driver</button>
        </form>
    </div>
</body>

</html>
