<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    // If not logged in, redirect to the sign-in page
    header('Location: signin.php');
    exit();
}

// If logged in, proceed with the admin page content
include('../admin/partials/header.php');
include('../admin/partials/sidebar.php');

// Add your main admin page content here
?>

