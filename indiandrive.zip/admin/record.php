<?php
session_start();

// Ensure that the user is logged in as a staff member
if (!isset($_SESSION['staff_id'])) {
    header("Location: staff_login.php");
    exit();
}

include('conn.php'); // Database connection

$staff_id = $_SESSION['staff_id'];
$error = '';

// Fetch forms filled by the logged-in staff member
$query_forms = "SELECT form_name, COUNT(id) AS form_count 
                FROM forms_filled 
                WHERE staff_id = ? 
                GROUP BY form_name";
$stmt_forms = $conn->prepare($query_forms);

if ($stmt_forms === false) {
    die("Error preparing forms statement: " . $conn->error);
}

$stmt_forms->bind_param('s', $staff_id);
$stmt_forms->execute();
$result_forms = $stmt_forms->get_result();

$forms_data = [];
while ($row = $result_forms->fetch_assoc()) {
    $forms_data[] = $row;
}
$stmt_forms->close();

// Fetch total drivers registered by the logged-in staff member
$query_drivers = "SELECT COUNT(*) AS driver_count FROM driver_info WHERE staff_id = ?";
$stmt_drivers = $conn->prepare($query_drivers);

if ($stmt_drivers === false) {
    die("Error preparing drivers statement: " . $conn->error);
}

$stmt_drivers->bind_param('s', $staff_id);
$stmt_drivers->execute();
$result_drivers = $stmt_drivers->get_result();

if ($result_drivers === false) {
    die("Error executing drivers query: " . $stmt_drivers->error);
}

$driver_count = $result_drivers->fetch_assoc()['driver_count'];
$stmt_drivers->close();

$conn->close();
?>

<?php include('partials/header.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Records</title>
    <link rel="stylesheet" href="css/admin.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Additional CSS for Record Page */

        .content {
            margin: 20px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .chart-container {
            width: 100%;
            max-width: 800px;
            margin: auto;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        h3 {
            text-align: center;
            color: #555;
            margin-top: 30px;
        }

        .error {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }

        /* Styling for up-content */
        .up-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 20px;
        }

        .actions {
            display: flex;
            align-items: center;
        }

        .search {
            margin-right: 20px;
        }

        .search-bar {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 200px;
        }

        .btns .btn {
            padding: 10px 15px;
            background-color: #28a745;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            margin-right: 10px;
            display: flex;
            align-items: center;
        }

        .btns .btn:hover {
            background-color: #218838;
        }

        .btns .btn i {
            margin-right: 5px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .up-content {
                flex-direction: column;
                align-items: flex-start;
            }

            .search {
                margin-right: 0;
                margin-bottom: 10px;
            }

            .search-bar {
                width: 100%;
            }

            .btns .btn {
                margin-right: 0;
                margin-bottom: 5px;
            }

            .chart-container {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="up-content">
        <div class="actions">
            <div class="search">
                <input type="text" placeholder="Search..." class="search-bar">
            </div>
            <div class="btns">
                <a href="../manual_reg.php" class="btn add"><i class="fas fa-plus"></i> Add New Driver</a>
            </div>
        </div>
    </div>

    <div class="content">
        <h2>Forms Filled by <?php echo htmlspecialchars($_SESSION['staff_name']); ?></h2>

        <?php
            if (!empty($error)) {
                echo '<div class="error">' . htmlspecialchars($error) . '</div>';
            }
        ?>

        <div class="chart-container">
            <canvas id="formsChart"></canvas>
        </div>

        <h3>Total Drivers Registered: <?php echo htmlspecialchars($driver_count); ?></h3>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var formsData = <?php echo json_encode($forms_data); ?>;

            var formNames = formsData.map(function(data) { return data.form_name; });
            var formCounts = formsData.map(function(data) { return data.form_count; });

            var ctx = document.getElementById('formsChart').getContext('2d');
            var formsChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: formNames,
                    datasets: [{
                        label: 'Number of Forms Filled',
                        data: formCounts,
                        backgroundColor: 'rgba(54, 162, 235, 0.6)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            precision: 0,
                            title: {
                                display: true,
                                text: 'Count'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Form Name'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        },
                        title: {
                            display: true,
                            text: 'Forms Filled by You'
                        },
                        tooltip: {
                            enabled: true
                        }
                    }
                }
            });
        });
    </script>
</body>
</html>
