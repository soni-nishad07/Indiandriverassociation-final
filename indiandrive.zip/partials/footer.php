<div class="footer">
        <div class="footer-data">
          <img src="images/ft-logo.png" alt="" class="footer-logo" />
          <p>Indian Drivers Association,<br> Oppo. St Francis School, <br> Begur Road Hongasandra, 
         <br> Bangalore, 560068</p>
        </div>
        <div class="links">
          <h3>QUICK LINKS</h3>
          <div class="list">
            <a href="index.html">Home</a>
            <a href="about.php">About Us</a>
            <a href="#gallery">Gallery</a>
            <a href="contact.html">Contact Us</a>
          </div>
        </div>
    </div>