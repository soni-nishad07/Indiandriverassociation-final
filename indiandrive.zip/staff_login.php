<?php
session_start();
include 'admin/conn.php';

$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Validate input
    if (empty($email) || empty($password)) {
        $error = "Please fill in all the fields.";
    } else {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Please enter a valid email.";
        } else {
            $query = "SELECT * FROM staff_members WHERE email = ?";
            if ($stmt = $conn->prepare($query)) {
                $stmt->bind_param('s', $email);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows === 1) {
                    $staff = $result->fetch_assoc();

                    if (password_verify($password, $staff['password'])) {
                        // Set session variables
                        $_SESSION['staff_id'] = $staff['staff_id'];
                        $_SESSION['staff_name'] = $staff['staff_name'];
                        $_SESSION['staff_email'] = $staff['email'];

                        // Regenerate session ID to prevent fixation
                        session_regenerate_id(true);

                        // Log the login time
                        $login_time = date('Y-m-d H:i:s');
                        $log_sql = "INSERT INTO staff_login_summary (staff_id, login_time) VALUES (?, ?)";
                        if ($log_stmt = $conn->prepare($log_sql)) {
                            $log_stmt->bind_param("ss", $_SESSION['staff_id'], $login_time);
                            $log_stmt->execute();
                            $log_stmt->close();
                        }

                        // Redirect to record.php
                        header("Location: admin/record.php");
                        exit();
                    } else {
                        $error = "Incorrect password. Please try again.";
                    }
                } else {
                    $error = "No account found with that email.";
                }

                $stmt->close();
            } else {
                $error = "Something went wrong: " . $conn->error;
            }
        }
    }

    $conn->close();
}
?>

<?php include('./partials/header.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Login</title>
    <link rel="stylesheet" href="css/admin.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .login-container {
            width: 350px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .login-container h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            color: #555;
            margin-bottom: 5px;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #aaa;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .error {
            color: red;
            margin-bottom: 15px;
            text-align: center;
        }

        .btn {
            width: 100%;
            padding: 10px;
            background-color: #4285F4;
            border: none;
            color: white;
            cursor: pointer;
            border-radius: 4px;
            font-size: 16px;
        }

        .btn:hover {
            background-color: #357ae8;
        }

        .register-link {
            text-align: center;
            margin-top: 10px;
        }

        .register-link a {
            color: #4285F4;
            text-decoration: none;
        }

        .register-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Staff Login</h2>

        <?php
            if (!empty($error)) {
                echo '<div class="error">' . htmlspecialchars($error) . '</div>';
            }
        ?>

        <form action="staff_login.php" method="POST">
            <div class="form-group">
                <label for="email">Email:</label>
                <input 
                    type="email" 
                    name="email" 
                    id="email" 
                    value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" 
                    required
                >
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input 
                    type="password" 
                    name="password" 
                    id="password" 
                    required 
                >
            </div>
            <button type="submit" class="btn">Login</button>
        </form>

        <div class="register-link">
            Don't have an account? <a href="signup.php">Register Here</a>
        </div>
    </div>
</body>
</html>
